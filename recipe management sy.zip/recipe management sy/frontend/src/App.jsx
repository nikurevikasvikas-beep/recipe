
import { useEffect, useState } from "react";
import "./App.css";

const API = "http://localhost:5000/api/recipes";

function App() {
  const [recipes, setRecipes] = useState([]);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const [message, setMessage] = useState("");

  const [form, setForm] = useState({
    name: "",
    ingredients: "",
    category: "Breakfast",
    preparationTime: 15,
    instructions: ""
  });

  const [editingId, setEditingId] = useState(null);

  async function loadRecipes() {
    try {
      const response = await fetch(API);
      if (!response.ok) throw new Error("Could not load recipes");
      setRecipes(await response.json());
    } catch {
      setMessage("Cannot connect to backend. Start the server first.");
    }
  }

  useEffect(() => {
    loadRecipes();
  }, []);

  async function saveRecipe(e) {
    e.preventDefault();

    const data = {
      ...form,
      ingredients: form.ingredients
        .split(",")
        .map(item => item.trim())
        .filter(Boolean),
      preparationTime: Number(form.preparationTime)
    };

    try {
      const response = await fetch(
        editingId ? `${API}/${editingId}` : API,
        {
          method: editingId ? "PUT" : "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data)
        }
      );

      const result = await response.json();
      if (!response.ok) throw new Error(result.message);

      setMessage(editingId ? "Recipe updated!" : "Recipe added!");
      setEditingId(null);
      setForm({
        name: "",
        ingredients: "",
        category: "Breakfast",
        preparationTime: 15,
        instructions: ""
      });
      await loadRecipes();
    } catch (error) {
      setMessage(error.message || "Something went wrong");
    }
  }

  function editRecipe(recipe) {
    setEditingId(recipe._id);
    setForm({
      name: recipe.name,
      ingredients: recipe.ingredients.join(", "),
      category: recipe.category,
      preparationTime: recipe.preparationTime,
      instructions: recipe.instructions || ""
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function deleteRecipe(id) {
    if (!window.confirm("Delete this recipe?")) return;

    try {
      const response = await fetch(`${API}/${id}`, {
        method: "DELETE"
      });
      if (!response.ok) throw new Error("Could not delete recipe");
      setMessage("Recipe deleted!");
      await loadRecipes();
    } catch (error) {
      setMessage(error.message);
    }
  }

  async function toggleFavorite(recipe) {
    try {
      const response = await fetch(`${API}/${recipe._id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ favorite: !recipe.favorite })
      });
      if (!response.ok) throw new Error("Could not update favorite");
      await loadRecipes();
    } catch (error) {
      setMessage(error.message);
    }
  }

  const visibleRecipes = recipes.filter(recipe => {
    const matchesSearch =
      recipe.name.toLowerCase().includes(search.toLowerCase());

    const matchesCategory =
      !category || recipe.category === category;

    return matchesSearch && matchesCategory;
  });

  return (
    <main className="container">
      <header className="hero">
        <p className="eyebrow">YOUR PERSONAL COOKBOOK</p>
        <h1>Recipe Management Platform 🍲</h1>
        <p>Discover, save and organize your favorite recipes.</p>
      </header>

      <section className="panel">
        <h2>{editingId ? "Edit Recipe" : "Add a New Recipe"}</h2>

        <form onSubmit={saveRecipe}>
          <label>Recipe Name</label>
          <input
            required
            placeholder="e.g. Vegetable Pulao"
            value={form.name}
            onChange={e => setForm({ ...form, name: e.target.value })}
          />

          <label>Ingredients (separate with commas)</label>
          <input
            required
            placeholder="Rice, onion, carrot, salt"
            value={form.ingredients}
            onChange={e => setForm({
              ...form,
              ingredients: e.target.value
            })}
          />

          <label>Category</label>
          <select
            value={form.category}
            onChange={e => setForm({
              ...form,
              category: e.target.value
            })}
          >
            <option>Breakfast</option>
            <option>Lunch</option>
            <option>Dinner</option>
            <option>Dessert</option>
            <option>Snacks</option>
            <option>Drinks</option>
          </select>

          <label>Preparation Time (minutes)</label>
          <input
            type="number"
            min="1"
            required
            value={form.preparationTime}
            onChange={e => setForm({
              ...form,
              preparationTime: e.target.value
            })}
          />

          <label>Instructions</label>
          <textarea
            placeholder="Explain how to prepare the recipe"
            value={form.instructions}
            onChange={e => setForm({
              ...form,
              instructions: e.target.value
            })}
          />

          <button type="submit">
            {editingId ? "Update Recipe" : "Add Recipe"}
          </button>

          {editingId && (
            <button
              type="button"
              className="secondary"
              onClick={() => {
                setEditingId(null);
                setForm({
                  name: "",
                  ingredients: "",
                  category: "Breakfast",
                  preparationTime: 15,
                  instructions: ""
                });
              }}
            >
              Cancel Edit
            </button>
          )}
        </form>

        {message && <p className="message">{message}</p>}
      </section>

      <section className="recipes-section">
        <h2>Explore Recipes</h2>

        <div className="filters">
          <input
            placeholder="🔍 Search recipes..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />

          <select
            value={category}
            onChange={e => setCategory(e.target.value)}
          >
            <option value="">All Categories</option>
            <option>Breakfast</option>
            <option>Lunch</option>
            <option>Dinner</option>
            <option>Dessert</option>
            <option>Snacks</option>
            <option>Drinks</option>
          </select>
        </div>

        <div className="recipe-grid">
          {visibleRecipes.map(recipe => (
            <article className="recipe-card" key={recipe._id}>
              <div className="food-icon">🍽️</div>
              <span className="category">{recipe.category}</span>
              <h3>{recipe.name}</h3>
              <p>⏱️ {recipe.preparationTime} minutes</p>

              <h4>Ingredients</h4>
              <p>{recipe.ingredients.join(", ")}</p>

              <h4>Instructions</h4>
              <p>{recipe.instructions || "No instructions added yet."}</p>

              <div className="actions">
                <button onClick={() => toggleFavorite(recipe)}>
                  {recipe.favorite ? "❤️ Saved" : "♡ Save"}
                </button>
                <button
                  className="secondary"
                  onClick={() => editRecipe(recipe)}
                >
                  Edit
                </button>
                <button
                  className="danger"
                  onClick={() => deleteRecipe(recipe._id)}
                >
                  Delete
                </button>
              </div>
            </article>
          ))}
        </div>

        {visibleRecipes.length === 0 && (
          <p className="empty">No recipes found. Add your first recipe!</p>
        )}
      </section>
    </main>
  );
}

export default App;
