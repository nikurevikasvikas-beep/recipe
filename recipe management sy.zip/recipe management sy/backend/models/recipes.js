
const mongoose = require("mongoose");

const recipeSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  ingredients: {
    type: [String],
    required: true
  },
  category: {
    type: String,
    required: true
  },
  preparationTime: {
    type: Number,
    required: true
  },
  instructions: {
    type: String,
    default: ""
  },
  favorite: {
    type: Boolean,
    default: false
  }
}, { timestamps: true });

module.exports = mongoose.model("Recipe", recipeSchema);
